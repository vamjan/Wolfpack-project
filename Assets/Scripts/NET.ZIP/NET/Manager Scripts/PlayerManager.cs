﻿using UnityEngine;
using System.Collections;

namespace Wolfpack.Managers
{
    public class PlayerManager : MonoBehaviour
    {

        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
