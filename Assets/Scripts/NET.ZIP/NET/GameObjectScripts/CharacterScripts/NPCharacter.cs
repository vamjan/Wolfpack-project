﻿using UnityEngine;
using System.Collections;
using System;

namespace Wolfpack.Character
{
    public class NPCharacter : Character
    {
        
    }
}
